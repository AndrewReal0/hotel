 <div class="col-sm-4 text-left">
                       <h5><strong> Departamento de investigación </strong></h5>
                    <ul>
                        <li><a href="#">grupohydra@unisangil.edu.co</a></br> <i> Grupo de estudios avanzados.</i></li></br>
                        <li><a href="#">hbaron@unisangil.edu.co</a></br> <i> Director grupo HYDRA.</i></li></br>
                        <li><a href="#">investigacionessagil@unisangil.edu.co</a> </br><i> Coordinadora departamento de investigación.</i></li>
                    </ul>
                </div>
            <div class="col-sm-4 text-left">
               
                    <h5><strong> Facultad de Ingeniería</strong></h5>
                     <ul>
                        <li><a href="#">ylongas@unisangil.edu.co</a></br><i> Directora Ing Sistemas.</i></li></br>
                        <li><a href="#">pperez@unisangil.edu.co</a></br><i> Director proyeto integradore.</i></li>
                        <!--<li><a href="#">investigacionessagil@unisangil.edu.co</a> Coordinadora departamento de investigación.</li>-->
                    </ul>
                </div>
                
                
            </div>

            <div class="row"><!-- Begin Sub Footer -->
               
                     </br>
                        <div ><span class=" glyphicon glyphicon-copyright-mark"></span> Copyright Grupo de Investigación HYDRA.</div>
                        <div>
                            <span class="right">
                            <a href="../../index.php">Inicio</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="#">Semilleros</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="../contacto.html">Contacto</a>
                            </span>
                        
                    </div>
            </div>
            <!-- End Sub Footer -->
